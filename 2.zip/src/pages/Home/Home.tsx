
function Home() {
  return (
    <div>خانه</div>
  )
}

export default Home