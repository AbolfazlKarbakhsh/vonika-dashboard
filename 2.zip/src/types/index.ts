export type BaseSearchParams = {
  page: number;
  per_page: number;
  search: string;
};
